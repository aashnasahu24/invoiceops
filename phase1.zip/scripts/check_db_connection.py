
import os
from sqlalchemy import create_engine, text
from dotenv import load_dotenv

load_dotenv()

database_url = os.getenv("DATABASE_URL")

if not database_url:
    raise SystemExit("ERROR: DATABASE_URL is not set. Check your .env file.")

try:
    engine = create_engine(database_url, pool_pre_ping=True)

    with engine.connect() as connection:
        result = connection.execute(text("""
            SELECT
                current_database(),
                current_user,
                version()
        """))

        database, user, version = result.fetchone()

        print("SUCCESS: Connected to PostgreSQL!")
        print(f"Database: {database}")
        print(f"User: {user}")
        print(f"Version: {version}")

    engine.dispose()

except Exception as e:
    print("FAILED: Could not connect to PostgreSQL.")
    print(f"Error: {e}")
