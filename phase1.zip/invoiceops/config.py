"""Central configuration: environment settings and v1 business-policy constants.

Two separate concerns live here on purpose:
- ``Settings``: deployment/environment values (DB URL, API keys, binaries).
- ``PolicyConfig``: business-rule thresholds. These are prototype demo policy,
  versioned so every stored decision can say which rules produced it.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from decimal import Decimal
from functools import lru_cache
from pathlib import Path

from dotenv import load_dotenv

PROJECT_ROOT = Path(__file__).resolve().parents[1]


@dataclass(frozen=True)
class Settings:
    database_url: str
    gemini_api_key: str | None
    gemini_model: str | None
    tesseract_cmd: str | None


@dataclass(frozen=True)
class PolicyConfig:
    """Prototype business policy (v1). Not universal accounting policy."""

    version: str = "v1"
    # Max relative difference between invoice and PO unit price (2%).
    price_tolerance_pct: Decimal = Decimal("0.02")
    # Max absolute rounding difference for totals/lines (INR 1 in the fixtures).
    rounding_tolerance: Decimal = Decimal("1.00")
    # OCR pages below this mean word confidence (0-100) become a review signal.
    min_ocr_confidence: float = 75.0
    line_match_threshold: int = 85
    vendor_name_threshold: int = 70
    soft_duplicate_days: int = 7


def default_sqlite_url() -> str:
    """Absolute path so the DB location never depends on the working directory."""
    return f"sqlite:///{(PROJECT_ROOT / 'invoiceops.db').as_posix()}"


def normalize_database_url(url: str) -> str:
    """Make provider-style URLs (Neon, Render, Heroku) use the psycopg v3 driver.

    ``postgres://`` and ``postgresql://`` would otherwise make SQLAlchemy look
    for psycopg2, which is not installed.
    """
    url = url.strip()
    for prefix in ("postgres://", "postgresql://"):
        if url.startswith(prefix):
            return "postgresql+psycopg://" + url[len(prefix):]
    return url


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    load_dotenv(PROJECT_ROOT / ".env")
    # `or` (not a getenv default) so an empty `DATABASE_URL=` also falls back.
    database_url = os.getenv("DATABASE_URL") or default_sqlite_url()
    return Settings(
        database_url=normalize_database_url(database_url),
        gemini_api_key=os.getenv("GEMINI_API_KEY") or None,
        gemini_model=os.getenv("GEMINI_MODEL") or None,
        tesseract_cmd=os.getenv("TESSERACT_CMD") or None,
    )


DEFAULT_POLICY = PolicyConfig()

# Model identifier attached to the committed offline replay fixtures. This is
# intentionally separate from GEMINI_MODEL, which controls live extraction.
REPLAY_FIXTURE_MODEL = "gemini-3.5-flash-lite"
